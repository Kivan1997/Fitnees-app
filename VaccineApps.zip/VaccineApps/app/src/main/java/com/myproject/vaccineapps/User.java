package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class User extends AppCompatActivity {

    //declare components
    Button btn_login,btn_cancel;
    EditText emailEt, passwordEt;
    TextView btn_signup;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        //declare components
        //initialize UI
        btn_login = (Button) findViewById(R.id.login_page_btn);
        btn_cancel = (Button) findViewById(R.id.btn_cancel);
        btn_signup = findViewById(R.id.register_btn);
        emailEt = (EditText) findViewById(R.id.email_edt_text);
        passwordEt = (EditText) findViewById(R.id.pass_edt_text);

        DB = new DBHelper(this);

        //login button - check auth user and login
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = emailEt.getText().toString();
                String password = passwordEt.getText().toString();

                if (email.equals("") || password.equals("")) {
                    Toast.makeText(User.this, "Please enter email or password!", Toast.LENGTH_LONG).show();
                } else {
                    Boolean checkemailpass = DB.checkemailpassword(email, password);
                    if (checkemailpass == true) {
                        Toast.makeText(User.this, "Login Successfully", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(User.this, MenuUser.class));
                        finish();
                    } else {
                        Toast.makeText(User.this, "Login Unsuccessfully", Toast.LENGTH_LONG).show();
                    }
                }
            }
        }); //end btn_login

        //new user button - go to signup page to register new user
        btn_signup.setOnClickListener((v) -> {
            startActivity(new Intent(User.this, SignUp.class));
            finish();
        }); //end btn_signup

        btn_cancel.setOnClickListener((v) -> {
            startActivity(new Intent(User.this, MainActivity.class));
            finish();
        });

    }
}
