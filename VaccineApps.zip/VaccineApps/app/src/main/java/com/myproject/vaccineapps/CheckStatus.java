package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CheckStatus extends AppCompatActivity {

    //TextView Ic, nm,Date,Time, Location;
    Button btn_back;
    DBHelper DB;
    RecyclerView recyclerView;
    ArrayList<String> ic, name, date, time, location;
    AdapterVaccine adapterVaccine;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_status);

        DB = new DBHelper(this);

        btn_back = (Button)findViewById(R.id.back_button);

        ic = new ArrayList<>();
        name = new ArrayList<>();
        date = new ArrayList<>();
        time = new ArrayList<>();
        location = new ArrayList<>();

        recyclerView = findViewById(R.id.recviewS);
        adapterVaccine = new AdapterVaccine(this,ic, name, date, time, location);
        recyclerView.setAdapter(adapterVaccine);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        displayVaccine();
        //login button - back to main activity page
        btn_back.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(CheckStatus.this, MenuUser.class));
                finish();
            }

        });

    }

    private void displayVaccine() {
        Cursor crsr = DB.getStatus();
        if(crsr.getCount()==0)
        {
            Toast.makeText(CheckStatus.this, "No Entry", Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            while(crsr.moveToNext())
            {
                ic.add(crsr.getString(0));
                name.add(crsr.getString(1));
                date.add(crsr.getString(2));
                time.add(crsr.getString(3));
                location.add(crsr.getString(4));

            }
        }
    }
}
