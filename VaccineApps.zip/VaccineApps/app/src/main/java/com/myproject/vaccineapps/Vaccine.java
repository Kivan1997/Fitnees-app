package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class Vaccine extends AppCompatActivity {

    Button addbtn, updatebtn;
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vaccine);

        addbtn = (Button) findViewById(R.id.add_btn);
        updatebtn = (Button) findViewById(R.id.update_btn);
        back = (ImageView) findViewById(R.id.back_button);

        addbtn.setOnClickListener((v) -> {
            startActivity(new Intent(Vaccine.this, Add.class));
            finish();
        });

        updatebtn.setOnClickListener((v) -> {
            startActivity(new Intent(Vaccine.this, UpdateVaccine.class));
            finish();
        });

        back.setOnClickListener((v) -> {
            startActivity(new Intent(Vaccine.this, HomeAdmin.class));
            finish();
        });
    }
}
