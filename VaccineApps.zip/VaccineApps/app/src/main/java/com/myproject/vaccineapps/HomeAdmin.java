package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class HomeAdmin extends AppCompatActivity {

    //declare button
    Button vaccinebtn, recipientbtn, statusbtn;
    ImageView logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_admin);

        //declare component
        vaccinebtn = (Button) findViewById(R.id.vaccine_btn);
        recipientbtn = (Button) findViewById(R.id.recipient_btn);
        statusbtn = (Button) findViewById(R.id.status_btn);
        logout = (ImageView) findViewById(R.id.sign_out_btn);

        vaccinebtn.setOnClickListener((v) -> {
            startActivity(new Intent(HomeAdmin.this, Vaccine.class));
            finish();
        });

        recipientbtn.setOnClickListener((v) -> {
            startActivity(new Intent(HomeAdmin.this, Recipient.class));
            finish();
        });

        statusbtn.setOnClickListener((v) -> {
            startActivity(new Intent(HomeAdmin.this, StatusVaccine.class));
            finish();
        });

        logout.setOnClickListener((v) -> {
            startActivity(new Intent(HomeAdmin.this, Admin.class));
            finish();
        });
    }
}
