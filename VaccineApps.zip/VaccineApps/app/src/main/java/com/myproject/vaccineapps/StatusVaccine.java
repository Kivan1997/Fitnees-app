package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class StatusVaccine extends AppCompatActivity {

    EditText Ic, nm,Date,Time, Location;
    ImageView back2, add;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_vaccine);

        Ic = findViewById(R.id.icnum);
        nm = findViewById(R.id.name);
        Date = findViewById(R.id.date);
        Time = findViewById(R.id.time);
        Location = findViewById(R.id.location);

        DB = new DBHelper( this);

        back2 = (ImageView) findViewById(R.id.back_btn2);

        add = (ImageView) findViewById(R.id.editicon);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get data input to database
                String ic = Ic.getText().toString().trim();
                String name = nm.getText().toString().trim();
                String date = Date.getText().toString().trim();
                String time = Time.getText().toString().trim();
                String location = Location.getText().toString().trim();


                Boolean insertVaccine = DB.insertVaccinedata (ic,name,date,time,location);
                if(insertVaccine==true){
                    // Sign in success, update UI with the signed-in user's information
                    Toast.makeText(StatusVaccine.this, "Add vaccine status Successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(StatusVaccine.this, HomeAdmin.class));
                    finish();
                }else{
                    Toast.makeText(StatusVaccine.this, "Add vaccine status Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        back2.setOnClickListener((v) -> {
            startActivity(new Intent(StatusVaccine.this, HomeAdmin.class));
            finish();
        });
    }
}
