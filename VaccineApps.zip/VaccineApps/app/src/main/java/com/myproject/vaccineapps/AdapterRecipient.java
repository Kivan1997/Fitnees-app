package com.myproject.vaccineapps;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterRecipient extends RecyclerView.Adapter<AdapterRecipient.MyViewHolder>{
    private Context context;
    private ArrayList ic, name, Phn, Add, email, password;

    public AdapterRecipient(Context context, ArrayList ic, ArrayList name, ArrayList Phn, ArrayList Add, ArrayList email, ArrayList password) {
        this.context = context;
        this.ic = ic;
        this.name = name;
        this.Phn = Phn;
        this.Add = Add;
        this.email = email;
        this.password = password;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.viewlistrecipient,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.ic.setText(String.valueOf(ic.get(position)));
        holder.name.setText(String.valueOf(name.get(position)));
        holder.Phn.setText(String.valueOf(Phn.get(position)));
        holder.Add.setText(String.valueOf(Add.get(position)));
        holder.email.setText(String.valueOf(email.get(position)));
        holder.password.setText(String.valueOf(password.get(position)));
    }

    @Override
    public int getItemCount() {
        return name.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView ic, name, Phn, Add, email, password;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ic = itemView.findViewById(R.id.icnum);
            name = itemView.findViewById(R.id.name);
            Phn = itemView.findViewById(R.id.nophone);
            Add = itemView.findViewById(R.id.addresstext);
            email = itemView.findViewById(R.id.email);
            password = itemView.findViewById(R.id.pwd);
        }
    }
}
