package com.myproject.vaccineapps;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterVaccine extends RecyclerView.Adapter<AdapterVaccine.MyViewHolder>{
    private Context context;
    private ArrayList ic,name,date,time,location;

    public AdapterVaccine(Context context, ArrayList ic, ArrayList name, ArrayList date, ArrayList time, ArrayList location) {
        this.context = context;
        this.ic = ic;
        this.name = name;
        this.date = date;
        this.time = time;
        this.location = location;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.viewliststatus,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.ic.setText(String.valueOf(ic.get(position)));
        holder.name.setText(String.valueOf(name.get(position)));
        holder.date.setText(String.valueOf(date.get(position)));
        holder.time.setText(String.valueOf(time.get(position)));
        holder.location.setText(String.valueOf(location.get(position)));

    }

    @Override
    public int getItemCount() {
        return name.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView ic, name, date, time, location;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            ic = itemView.findViewById(R.id.icnum1);
            name = itemView.findViewById(R.id.name1);
            date = itemView.findViewById(R.id.date1);
            time = itemView.findViewById(R.id.time1);
            location = itemView.findViewById(R.id.location1);

        }
    }
}

