package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class UpdateVaccine extends AppCompatActivity {

    Button cancel, btn_upd;
    ImageView back;
    EditText vName,eRate,suit,dose;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_vaccine);


        btn_upd = (Button)findViewById(R.id.upd_btn);
        vName = findViewById(R.id.vaccine_name1);
        eRate = findViewById(R.id.rate1);
        suit = findViewById(R.id.nophone1);
        dose = findViewById(R.id.doses1);

        cancel = (Button) findViewById(R.id.cancel_button);
        back = (ImageView) findViewById(R.id.back_btn);
        DB = new DBHelper( this);
        cancel.setOnClickListener((v) -> {
            startActivity(new Intent(UpdateVaccine.this, Vaccine.class));
            finish();
        });

        back.setOnClickListener((v) -> {
            startActivity(new Intent(UpdateVaccine.this, Vaccine.class));
            finish();
        });

        btn_upd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get data input to database
                String vcNAME = vName.getText().toString().trim();
                String Rate = eRate.getText().toString().trim();
                String eSuit = suit.getText().toString().trim();
                String Doses = dose.getText().toString().trim();

                Boolean Vaccinedata = DB.updateVaccine(vcNAME,Rate,eSuit,Doses);
                if(Vaccinedata==true){
                    // Sign in success, update UI with the signed-in user's information
                    Toast.makeText(UpdateVaccine.this, "Updated Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(UpdateVaccine.this, User.class));
                    finish();
                }else{
                    Toast.makeText(UpdateVaccine.this, "Update Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
