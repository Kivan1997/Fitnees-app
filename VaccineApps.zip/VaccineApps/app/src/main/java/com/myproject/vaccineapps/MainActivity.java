package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //declare button
    Button adminbtn, userbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //declare component
        adminbtn = (Button) findViewById(R.id.btnAdmin);

        //button to go Admin
        adminbtn.setOnClickListener((v) -> {
            startActivity(new Intent(MainActivity.this, Admin.class));
            finish();
        });

        userbtn= (Button) findViewById(R.id.btnUser);

        //button to go Admin
        userbtn.setOnClickListener((v) -> {
            startActivity(new Intent(MainActivity.this, User.class));
            finish();
        });
    }
}
