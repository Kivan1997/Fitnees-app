package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class Add extends AppCompatActivity {

    Button btncancel, btn_add;
    EditText vName,eRate,suit,dose;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        btncancel = (Button) findViewById(R.id.cancel_btn);
        btn_add = (Button)findViewById(R.id.add_btn);
        vName = findViewById(R.id.vaccine_name);
        eRate = findViewById(R.id.rate);
        suit = findViewById(R.id.nophone);
        dose = findViewById(R.id.doses);

        DB = new DBHelper( this);

        btncancel.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(Add.this, Vaccine.class));
                finish();
            }

        });

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get data input to database
                String vcNAME = vName.getText().toString().trim();
                String Rate = eRate.getText().toString().trim();
                String eSuit = suit.getText().toString().trim();
                String Doses = dose.getText().toString().trim();

                Boolean vaccine = DB.insertvaccine (vcNAME,Rate,eSuit,Doses);
                if(vaccine==true){
                    Toast.makeText(Add.this, "Data Added Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Add.this, HomeAdmin.class));
                    finish();
                }else{
                    Toast.makeText(Add.this, "Add Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
