package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MenuUser extends AppCompatActivity {

    //declare components
    Button btn_vaccine, btn_update;
    ImageView btn_signout_to_main;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_user);

        //declare components
        btn_signout_to_main = (ImageView) findViewById(R.id.sign_out_btn);

        //login button - back to main activity page
        btn_signout_to_main.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuUser.this, User.class));
                finish();
            }

        });

        //declare components
        btn_vaccine = (Button)findViewById(R.id.vaccine_btn);

        //login button - back to main activity page
        btn_vaccine.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuUser.this, CheckStatus.class));
                finish();
            }

        });

        //declare components
        btn_update = (Button)findViewById(R.id.btn_update);

        //login button - back to main activity page
        btn_update.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuUser.this, UpdateUser.class));
                finish();
            }

        });

    }
}
