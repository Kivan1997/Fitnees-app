package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;

public class Admin extends AppCompatActivity {

    Button b1,b2;
    EditText ed1,ed2;

    int counter = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        b1 = (Button)findViewById(R.id.btnLogin);
        ed1 = (EditText)findViewById(R.id.editText);
        ed2 = (EditText)findViewById(R.id.editText2);

        b2 = (Button)findViewById(R.id.btnAdd);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = ed1.getText().toString();
                String password = ed2.getText().toString();

                if (email.equals("") || password.equals("")) {
                    Toast.makeText(Admin.this, "Please enter email or password!", Toast.LENGTH_LONG).show();
                } else {
                    if (email.equals("admin")||password.equals("123")) {
                        Toast.makeText(Admin.this, "Login Successfully", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(Admin.this, HomeAdmin.class));
                        finish();
                    } else {
                        Toast.makeText(Admin.this, "Login Failed", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        b2.setOnClickListener((v) -> {
            startActivity(new Intent(Admin.this, MainActivity.class));
            finish();
        });
    }
}
