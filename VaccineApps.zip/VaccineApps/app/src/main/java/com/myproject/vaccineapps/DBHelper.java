package com.myproject.vaccineapps;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public static final  String DBNAME = "Vaccine.db";

    public DBHelper(Context context) {
        super(context, "Vaccine.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Userdetails(ic TEXT primary key, name TEXT, phone TEXT, address TEXT, email TEXT, pwd TEXT)");
        DB.execSQL("create Table TableVaccine(vcName TEXT primary key, eRate TEXT, eSuit TEXT, Doses TEXT)");
        DB.execSQL("create Table Vaccinedetails(ic TEXT primary key, name TEXT, date TEXT, time TEXT, location TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int oldVersion, int newVersion) {
        DB.execSQL("drop Table if exists Userdetails");
        DB.execSQL("drop Table if exists TableVaccine");
        DB.execSQL("drop Table if exists Vaccinedetails");
    }

    public boolean insertuserdata(String ic, String name, String phone, String address, String email, String pwd) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ic", ic);
        contentValues.put("name", name);
        contentValues.put("phone", phone);
        contentValues.put("address", address);
        contentValues.put("email", email);
        contentValues.put("pwd", pwd);
        long result = DB.insert("Userdetails", null, contentValues);
        if (result == 1){
            return false;
        }else{
            return true;
        }
    }
    public boolean insertvaccine(String vcName, String eRate, String eSuit, String Doses) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("vcName", vcName);
        contentValues.put("eRate", eRate);
        contentValues.put("eSuit", eSuit);
        contentValues.put("Doses", Doses);
        long result = DB.insert("TableVaccine", null, contentValues);
        if (result == 1){
            return false;
        }else{
            return true;
        }
    }

    public boolean insertVaccinedata(String ic, String name, String date, String time, String location) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ic", ic);
        contentValues.put("name", name);
        contentValues.put("date", date);
        contentValues.put("time", time);
        contentValues.put("location", location);

        long result = DB.insert("Vaccinedetails", null, contentValues);
        if (result == 1){
            return false;
        }else{
            return true;
        }
    }

    public Cursor getStatus()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor crsr  = DB.rawQuery("Select * from Vaccinedetails", null);
        return crsr;
    }

    public Cursor getdata()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor  = DB.rawQuery("Select * from Userdetails", null);
        return cursor;
    }

    public boolean updateuserdata(String ic, String name, String phone, String address, String email, String pwd) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("phone", phone);
        contentValues.put("address", address);
        contentValues.put("email", email);
        contentValues.put("pwd", pwd);
        Cursor cursor = DB.rawQuery("Select * from Userdetails where ic = ?", new String[] {ic});
        if(cursor.getCount()>0) {
            long result = DB.update("Userdetails", contentValues, "ic=?", new String[] {ic});
            if (result == 1) {
                return false;
            } else {
                return true;
            }
        }else{
            return false;
        }
    }

    public boolean updateVaccine(String vcName, String eRate, String eSuit, String Doses) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues Values = new ContentValues();
        Values.put("eRate", eRate);
        Values.put("eSuit", eSuit);
        Values.put("Doses", Doses);
        Cursor cursor = DB.rawQuery("Select * from TableVaccine where vcName = ?", new String[] {vcName});
        if (cursor.getCount()>0) {
            long result = DB.update("TableVaccine", Values, "vcName=?", new String[] {vcName});
            if (result == 1) {
                return false;
            } else {
                return true;
            }
        }else{
                return false;
            }
        }

    public boolean checkemailpassword(String email, String pwd) {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Userdetails where email = ? and pwd = ?" , new String[] {email, pwd});
        if(cursor.getCount()>0){
            return true;
        }else{
            return false;
        }
    }

}

