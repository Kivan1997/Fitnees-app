package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class UpdateStatus extends AppCompatActivity {

    Button cancelbtn;
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_status);

        cancelbtn = (Button) findViewById(R.id.back_button);
        back = (ImageView) findViewById(R.id.back_btn);

        back.setOnClickListener((v) -> {
            startActivity(new Intent(UpdateStatus.this, HomeAdmin.class));
            finish();
        });

        cancelbtn.setOnClickListener((v) -> {
            startActivity(new Intent(UpdateStatus.this, HomeAdmin.class));
            finish();
        });

    }
}
