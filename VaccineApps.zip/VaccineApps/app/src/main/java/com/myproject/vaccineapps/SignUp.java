package com.myproject.vaccineapps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignUp extends AppCompatActivity {

    //declare components
    Button btn_back_to_login, btn_register;
    EditText icEt,nameEt,nophone,address,emailEt, passwordEt;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        //declare components
        //initialize UI
        btn_back_to_login = (Button)findViewById(R.id.login_page_btn);
        btn_register = (Button)findViewById(R.id.register_btn);
        icEt = findViewById(R.id.ic_text);
        nameEt = findViewById(R.id.name_text);
        nophone = findViewById(R.id.nophone);
        address = findViewById(R.id.address);
        emailEt = findViewById(R.id.email_edt_text);
        passwordEt = findViewById(R.id.pass_edt_text);

        DB = new DBHelper( this);

        //login button - back to main activity page
        btn_back_to_login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUp.this, MainActivity.class));
                finish();
            }

        }); //end btn_back_to_login


        //register button - register new user
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get data input to database
                String user_ic = icEt.getText().toString().trim();
                String user_name = nameEt.getText().toString().trim();
                String no_phone = nophone.getText().toString().trim();
                String adrs = address.getText().toString().trim();
                String user_email = emailEt.getText().toString().trim();
                String user_password = passwordEt.getText().toString().trim();

                Boolean checkinsertdata = DB.insertuserdata (user_ic,user_name,no_phone,adrs,user_email, user_password);
                if(checkinsertdata==true){
                    // Sign in success, update UI with the signed-in user's information
                    Toast.makeText(SignUp.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignUp.this, User.class));
                    finish();
                }else{
                    Toast.makeText(SignUp.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}//end btn_register
