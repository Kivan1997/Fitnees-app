package com.myproject.vaccineapps;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class Recipient extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<String> ic, name, Phn, Add, email, password;
    DBHelper DB;
    AdapterRecipient adapterRecipient;

    ImageView back1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipient);

        back1 = (ImageView) findViewById(R.id.back_btn1);

        back1.setOnClickListener((v) -> {
            startActivity(new Intent(Recipient.this, HomeAdmin.class));
            finish();
        });
        DB = new DBHelper(this);
        ic = new ArrayList<>();
        name = new ArrayList<>();
        Phn = new ArrayList<>();
        Add = new ArrayList<>();
        email = new ArrayList<>();
        password = new ArrayList<>();
        recyclerView = findViewById(R.id.recview);
        adapterRecipient = new AdapterRecipient(this,ic, name, Phn, Add, email, password);
        recyclerView.setAdapter(adapterRecipient);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        displaydata();
    }

    private void displaydata() {
        Cursor cursor = DB.getdata();
        if(cursor.getCount()==0)
        {
            Toast.makeText(Recipient.this, "No Entry", Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            while(cursor.moveToNext())
            {
                ic.add(cursor.getString(0));
                name.add(cursor.getString(1));
                Phn.add(cursor.getString(2));
                Add.add(cursor.getString(3));
                email.add(cursor.getString(4));
                password.add(cursor.getString(5));
            }
        }

    }
}
